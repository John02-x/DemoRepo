#!/bin/bash
echo "enter a number"
read a

if (($a%5==0 & $a%7==0))
	then
	echo "$a is divisible by 5 and 7"
else
	echo "not divisibk,ZSFDIjnm"
fi
