#!/bin/bash
echo "printing 1 to 3"

for i in {1..3}
do
	case $i in
		1) echo "one";;
		2) echo "two";;
		3) echo "three";;
	esac
done
