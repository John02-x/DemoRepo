#!/bin/bash
echo "Enter three numbers"
read a b c
if(( a > b & a > c  ))
	then
	echo "$a is the greatest"
elif (( b > a & b > c ))
	then 
	echo "$b is the greatest"
else
	echo "$c is the greatest"
fi
