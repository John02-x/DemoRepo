#!/bin/bash
echo "Enter string"
read a

reversed=$(echo "$a" | rev)

if (($a==$reversed))
	then 
		echo "P";
	else
		echo "NP";
fi
