#!/bin/bash
echo "Enter you pass"
read pass
case $pass in 
	"dac") echo "correct";;
	*) echo "incorrect";;
esac
