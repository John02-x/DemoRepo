#!/bin/bash
echo "enter 10 nos"
read a b c d e f g h i j

cnt1 = 0;
cnt2 = 0;
cnt3 = 0;

for x in {a..j}
do
	if(($x > 0))
	then
		((cnt1++))
	elif (($x < 0))
	then 
		((cnt2++))
	else
		((cnt3++))
	fi
done

echo "$cnt1"
echo "$cnt2"
echo "$cnt3"
