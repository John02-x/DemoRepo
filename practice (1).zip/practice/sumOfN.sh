#!/bin/bash

sum=0

for x in {1..100}
	do
		echo $x 
		sum=$(($x+$sum))
	done
echo "$sum"
