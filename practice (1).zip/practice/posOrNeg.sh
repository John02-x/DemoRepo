#!/bin/bash
echo "Enter the number"
read a
if(( $a > 0 ))
	then
	echo "$a is positive"
elif(( $a < 0 ))
	then
	echo "$a is negative"
elif(( $a == 0 ))
	then
	echo "$a is zero"
else
	echo "$a is not an number"
fi
