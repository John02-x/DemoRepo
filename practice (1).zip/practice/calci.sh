#!/bin/bash
echo "enter two number"
read a b
echo "enter operation"
read op

case $op in 
	"+") echo "$(($a+$b))";;
	"-") echo "$(($a-$b))";;
	
esac
