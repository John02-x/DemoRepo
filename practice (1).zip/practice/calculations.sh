echo $(whoami)

echo $(pwd)

echo $(tty)


