#!/bin/bash
echo "first 10 n no are"
for i in {1..10}
do
	echo $i
done
